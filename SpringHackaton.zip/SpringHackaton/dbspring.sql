-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 15 2023 г., 17:37
-- Версия сервера: 10.3.22-MariaDB-log
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dbspring`
--

-- --------------------------------------------------------

--
-- Структура таблицы `eventss`
--

CREATE TABLE `eventss` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `Date` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `Place` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `Time` time NOT NULL,
  `Photo` varchar(100) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Дамп данных таблицы `eventss`
--

INSERT INTO `eventss` (`Id`, `Name`, `Date`, `Place`, `Time`, `Photo`) VALUES
(1, 'Bingo game', '2022-12-28', 'Asosiy bino', '15:00:00', 'bingo.png'),
(2, 'Conversation club', '2022-12-27', 'Humo Arena', '17:00:00', 'conversation.png'),
(3, 'Book club', '2022-12-29', 'Kutubxona', '14:00:00', 'book.png'),
(4, 'Danca klass-master', '2022-12-22', 'Musiqa xonasi', '14:00:00', 'dance.png'),
(5, 'Making houses', '2022-12-27', 'Eko-park', '16:30:00', 'house.png'),
(6, 'Making healty food', '2022-12-28', 'Oshxona', '18:00:00', 'food.png');

-- --------------------------------------------------------

--
-- Структура таблицы `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `nameParent` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surnameParent` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `passport` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nameChild` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surnameChild` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdateChild` date NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `event` int(11) NOT NULL,
  `childPic` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volunteer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdate` date NOT NULL,
  `about` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `eventss`
--
ALTER TABLE `eventss`
  ADD PRIMARY KEY (`Id`);

--
-- Индексы таблицы `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event` (`event`,`volunteer`),
  ADD KEY `volunteer` (`volunteer`);

--
-- Индексы таблицы `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event` (`event`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `eventss`
--
ALTER TABLE `eventss`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`event`) REFERENCES `eventss` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `parents_ibfk_2` FOREIGN KEY (`volunteer`) REFERENCES `volunteers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`event`) REFERENCES `eventss` (`Id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
