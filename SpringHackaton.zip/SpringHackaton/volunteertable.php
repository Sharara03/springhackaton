<?php
//include("sqlib.php");

// if(isset($_COOKIE["volunteer"]))
// {
	
// } 

// else
// {
// 	header("location: index.php");
// } 
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- Page title -->
      <title>Time Share</title>
      <!--[if lt IE 9]>
      <script src="js/respond.js"></script>
      <![endif]-->
      <!-- Bootstrap Core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
      <!-- Icon fonts -->
      <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="fonts/flaticons/flaticon.css" rel="stylesheet" type="text/css">
      <link href="fonts/glyphicons/bootstrap-glyphicons.css" rel="stylesheet" type="text/css">
      <!-- Google fonts -->
      <link href="https://fonts.googleapis.com/css?family=Karla:400,600,700%7CCherry+Swash:400,700" rel="stylesheet">
      <!-- Style CSS -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Color Style CSS -->
      <link href="styles/maincolors.css" rel="stylesheet">
      <!-- CSS Plugins -->
      <link rel="stylesheet" href="css/plugins.css">
      <!-- LayerSlider CSS -->
      <link rel="stylesheet" href="js/layerslider/css/layerslider.css">
      <!-- Favicons-->
      <link rel="apple-touch-icon" sizes="72x72" href="apple-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="114x114" href="apple-icon-114x114.png">
      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
   </head>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
   
      <!--============== Navbar Starts ==============-->
      <nav class="navbar navbar-custom navbar-fixed-top">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-brand-centered">
            <i class="fa fa-bars"></i>
            </button>
            <div class="navbar-brand-centered page-scroll">
               <a href="#page-top"><img src="tayyor.png" class="img-responsive"  alt="" style="height:105px"></a>
            </div>
         </div>
         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="navbar-brand-centered">
            <div class="container">
                <ul class="nav navbar-nav page-scroll navbar-left">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="#about">About</a></li>
               </ul>
               <ul class="nav navbar-nav page-scroll navbar-right">
                  <li><a href="gallery.php">Gallery</a></li>
                  <li><a href="#about">Contact</a></li>
               </ul>
            </div>
         </div>
         <!-- /.navbar-collapse -->
      </nav>
       <!--============== // Navbar Ends ==============-->
	   
      
      </div>
      <!-- /container-fluid -->
      <!-- curve up svg -->
      <svg id="curveUp" class="hidden-xs hidden-sm" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 C 20 0 50 0 100 100 Z" />
      </svg>
      <!-- /curve up svg -->
<section id="catering" class="light-bg1 skrollable skrollable-between" data-center="background-position: 0% 0px;" data-top-bottom="background-position: 0% -20px;" data-bottom-top="background-position: 0% -40px;" style="background-position: 0% -16.2px;">
         <div class="container">
            <!-- Section Heading -->

            <div class="col-md-12">
               <!-- Pricing Container -->
               <div class="pricing-container">
                  <div class="row">

                     <!-- Price table 2 -->
                     <div class="col-md-4 res-margin aos-init aos-animate" data-aos="fade-up" data-aos-duration="1200">
                        <div class="pricing-table">
                           <div class="pricing-inner color2" style="background-color:#41aec0;">

                
         
                              <!-- Button -->
                              <div class="page-scroll">
                                 <a href="#">
                                    <div class="blob-btn" style="background-color:#fff;">
                                       Welcome to our personal desk<br>You will get various information about your team
                                       <span class="blob-btn__inner">
                                       <span class="blob-btn__blobs">
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       </span>
                                       </span>
                                    </div>
                                 </a>
                                 <!-- /button ends -->
                              </div>
                              <!-- /page-scroll -->
                           </div>
                           <!-- /pricing-inner -->
                        </div>
                        <!-- /Pricing-table -->
                     </div>
                     <!-- /col-md-4 -->

                     <!-- /col-md-4 -->
                  </div>
                  <!-- /row -->
               </div>
               <!-- /pricing-container -->
            </div>
            <!-- /col-md-12 -->
         </div>
         <!--/container -->
      </section>
	  
	  
  <section id="list">
         <div class="container">
            <!-- Section Heading -->
            <div class="" >
               <h2>List of children </h2>
            </div>
            <div class="col-md-12">
			
			
			
			  <?php
//				$choice = "kick-boxing";
			   $db = create_db("ts");
			   if(isset($_COOKIE["volunteer"]))
{
	$vol_id = $_COOKIE["volunteer"];
} 

			   $result = select($db, "children", "volunteer", $vol_id);
	//		   $result = select($db, "children", "activity", $choice);
			   
//			   print_r($result);
			   
//			   delete($db, "children", "name", "Dildora");
			   
			   for($i=0; $i<count($result); $i++)
			   {
			   $name = $result[$i]["name"];
			   $surname = $result[$i]["surname"];
			   $bio = $result[$i]["bio"];
			   
			   $date_of_birth = $result[$i]["date_of_birth"];
			   $date_of_birth = explode("-", $date_of_birth);
			   $date_of_birth = date("Y") - $date_of_birth[0];
			   
			   $image = $result[$i]["foto"];
			   //$phone = $result[$i]["phone"];
			  // $email = $result[$i]["email"];
			   $id = $result[$i]["id"];
			   
			   ?>
			
			
			  <div class="owl-item cloned" ><div class="blog-prev ">
                     <!-- image -->
                     <img src="<?php echo "server/children/".$image; ?>" alt="" class="img-responsive">
                     <!-- date -->
                     <!-- caption -->
                     <div class="blog-caption">
                        <a href="blog-single.html">
                           <h5><?php echo $name; echo " ";?><?php echo  $surname;?></h5>
                        </a>
                        <p>
						<?php echo  "Age: ".  $date_of_birth;?> <br>
						<?php echo  "About: ".  $bio;?> <br>
                        </p>
                        <!-- Post Info -->
                        <!-- /text-center -->
                     </div>
                     <!-- /blog-caption -->
                  </div></div>
				  <br clear="both"/>
				  <br clear="both"/>
			<?php
			   }
			   ?>
			
			
			
			</div>
                  
					 </div>
               <!--/owl-blog -->
            </div>
            <!--/col-md-12 -->
         </div>
         <!--/container -->
      </section>
      <!--============== Footer Starts ==============-->
     <footer class="bg-primary" id="about" style="background-color:#41aec0;">
         <div class="container">
            <div class="row text-center">
               <!-- social media and logo -->
               <div class="col-lg-4">
                  <h6  class="text-light">Opening Times</h6>
                  <ul class="ul-custom ul-no-margin text-light">
                     <li>Mon - fri: 9am-6pm</li>
                     <li>Holidays: Closed</li>
                  </ul>
               </div>
               <!-- /row -->
               <div class="col-lg-4">
                  <a href="#page-top"><img src="tayyor.png"  alt="" class="img-responsive center-block" style="height:150px"></a>
               </div>
               <div class="col-lg-4">
                  <!-- social-icons -->	
                  <h6  class="text-light">Follow us</h6>
                  <div class="social-media">
                     <a href="#" title=""><i class="fa fa-twitter"></i></a>
                     <a href="#" title=""><i class="fa fa-facebook"></i></a>
                     <a href="#" title=""><i class="fa fa-instagram"></i></a>
                  </div>
               </div>
               <!-- /col-lg-4 -->  			
            </div>
            <!-- /row -->
            <div class="row">
               <div class="col-md-12 credits text-center">
                  <p>Copyright © 2019 - Designed by  <a href="http://www.CyberKids.com">Cyber Kids</a></p>
                  <!-- /container -->
                  <!-- Go To Top Link -->
                  <div class="page-scroll hidden-sm hidden-xs">
                     <a href="#page-top" class="back-to-top"><i class="fa fa-angle-up"></i></a>
                  </div>
               </div>
               <!-- /col-md-12 -->
            </div>
            <!-- /row-->
         </div>
         <!-- /container -->
      </footer>
	
	  
      <!-- Core JavaScript Files -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>