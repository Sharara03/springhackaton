<?php include("control.php"); ?>

<!DOCTYPE html>
<html lang="en">
   
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
   
     
       <?php
      include_once "navbar.php";
   ?>
      <!-- Preloader -->
      <div id="loading">
         <div id="loading-center">
            <div id="loading-center-absolute">
               <div class="object-load" id="object_one"></div>
               <div class="object-load" id="object_two"></div>
               <div class="object-load" id="object_three"></div>
            </div>
         </div>
      </div>
      <!-- /preloader -->
	  <!-- ==== Slider ==== -->
      <div class="container-fluid page-scroll">
         <!-- ==== Slider ==== -->
         <div id="slider" style="width:1200px;height:900px;margin:0 auto;margin-bottom: 0px;">
            <!-- Slide 1 -->
            <div class="ls-slide" data-ls="duration:4000; transition2d:7; kenburnszoom:out; kenburnsscale:1.2;">
               <!-- bg image  -->
               <img src="img/img/SONY DSC-HX200V_20190308_143823.jpg" class="ls-bg" alt="" />
               <!-- text  -->
               <div class="ls-l header-wrapper" data-ls="offsetyin:150; durationin:700; delayin:200; easingin:easeOutQuint; rotatexin:20; scalexin:1.4; offsetyout:600; durationout:400; parallaxlevel:0;">
                  <div class="header-text">
                     <h1>Welcome to Time Share</h1>
                     <p class="header-p">We offer you various activities to spend your child's time usefully!   
                     </p>
                  </div>
                  <!-- header-text  -->
               </div>
               <!-- ls-l  -->
            </div>
            <!-- ls-slide -->
            <!-- Slide 2 -->
            <div class="ls-slide" data-ls="duration:4000; transition2d:7; kenburnszoom:out; kenburnsscale:1.2;">
               <!-- bg image  -->
               <img src="img/img/SONY DSC-HX200V_20190308_110227.jpg" class="ls-bg" alt="" />
               <!-- text  -->
               <div class="ls-l header-wrapper" data-ls="offsetyin:150; durationin:700; delayin:200; easingin:easeOutQuint; rotatexin:20; scalexin:1.4; offsetyout:600; durationout:400; parallaxlevel:0;">
                  <div class="header-text">
                     <h1>See how fun it is to children</h1>
                     <p class="header-p">They get unforgetable memories and profitable experience 
                     </p>
                  </div>
                  <!-- header-text  -->
               </div>
               <!-- ls-l  -->
            </div>
            <!-- ls-slide -->
            <!-- Slide 3 -->
            <div class="ls-slide" data-ls="duration:4000; transition2d:7; kenburnszoom:out; kenburnsscale:1.2;">
               <!-- bg image  -->
               <img src="img/img/SONY DSC-HX200V_20190308_134116.jpg" class="ls-bg" alt="" />
               <!-- text  -->
               <div class="ls-l header-wrapper" data-ls="offsetyin:150; durationin:700; delayin:200; easingin:easeOutQuint; rotatexin:20; scalexin:1.4; offsetyout:600; durationout:400; parallaxlevel:0;">
                  <div class="header-text">
                     <h1>Your payment will serve to your child's use</h1>
                     <p class="header-p">Registrate and join our rank today!
                     </p>
                  </div>
                  <!-- header-text  -->
               </div>
               <!-- ls-l  -->
            </div>
            <!-- ls-slide -->
         </div>
         <!-- /slider -->
      </div>
      <!-- /container-fluid -->
      <!-- curve up svg -->
    
      <!-- /curve up svg -->

      <!-- ==== Catering ==== -->
      <section id="registration" class="light-bg1" data-center="background-position: 0% 0px;"
               data-top-bottom="background-position: 0% -20px;"
              data-bottom-top="background-position: 0% -40px;">
         <div style="margin-top: 50px;" class="container">
           
            <div class="col-md-12">
               <!-- Pricing Container -->
               <div class="pricing-container">
                  <div class="row">
                     <!-- Price table 1 -->
                     <div class="col-md-6"  data-aos-duration="800">
                        <div class="pricing-table">
                           <div class="pricing-inner color1" style="background-color:#41aec0;">
                             
                             
                              <!-- Button -->
                              <div class="page-scroll">
                                 <a  href="parents.php">
                                    <div class="blob-btn" style="background-color: #fdfd05;">
                                       Parent
                                       <span class="blob-btn__inner">
                                       <span class="blob-btn__blobs">
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       </span>
                                       </span>
                                    </div>
                                 </a>
                                 <!-- /button ends -->
                              </div>
							  
                              <!-- /page-scroll -->
                           </div>
                           <!-- /pricing-inner -->
                        </div>
                        <!-- /Pricing-table -->
                     </div>
                     <!-- /col-md-4 -->
                     <!-- Price table 2 -->
                     <div class="col-md-6 res-margin"  data-aos-duration="1200">
                        <div class="pricing-table">
                           <div class="pricing-inner color2" style="background-color:#41aec0;">
                             <!-- Button -->
                              <div class="page-scroll">
                                 <a  href="volunteer.php">
                                    <div class="blob-btn" style="background-color: #fdfd05;">
                                       Volunteer
                                       <span class="blob-btn__inner">
                                       <span class="blob-btn__blobs">
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       <span class="blob-btn__blob"></span>
                                       </span>
                                       </span>
                                    </div>
                                 </a>
                                 <!-- /button ends -->
                              </div>
                              <!-- /page-scroll -->
                           </div>
                           <!-- /pricing-inner -->
                        </div>
                        <!-- /Pricing-table -->
                     </div>
                     <!-- /col-md-4 -->
                    
                  </div>
                  <!-- /row -->
               </div>
               <!-- /pricing-container -->
            </div>
            <!-- /col-md-12 -->
         </div>
         <!--/container -->
      </section>
      <!-- / section--> 
     
     
     
      <!-- ==== Contact ==== -->
      <section id="contact" class="container-fluid">
         <div  class="container">
            <div class="col-lg-12">
               <!-- Section heading -->
               <div class="section-heading">
                  <h2 style="margin-top:100px ;">Contact Us</h2>
               </div>
            </div>
            <!-- Contact icons -->
            <div class="row">
               <div style="margin-top:50px ;" class="col-lg-12 col-md-12">
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-envelope top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Send us a Message</p>
                           <p>Email address: <br/><a href="mailto:email@timeshare.com">email@timeshare.com</a></p>
                        </div>
                     </div>
                  </div>
                  <!-- /contact-icon-->
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-map-marker top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Visit our Location</p>
                           <p>Almazar district 1-a house<br/>Tashkent</p>
                        </div>
                     </div>
                  </div>
                  <!-- /contact-icon-->
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-phone top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Call us</p>
                           <p>Phone numbers: <br/>(94) 123-45-67 <br/>(94) 123-45-67</p>
                        </div>
                     </div>
                     <!-- /contact-icon-->
                  </div>
                  <!-- /col-md-4-->
               </div>
               <!-- /col-lg -->
            </div>
            <div class="row margin1">
               
               <!-- / col-md-5-->
               <!-- Map with Reveal Box -->
               <div class="col-md-6 col-md-offset-1 revealedBox goLeft res-margin">
                  <!-- Map -->
                  <div height="0" class="" id="map-canvas">                      
               
               </div>

               <!--/col-lg-6  -->
            </div>
            <!--/row -->   
         </div>
         <!-- /container-->
      </section> 
      <!-- / section-->
      <!--============== Footer Starts ==============-->
      <?php
         include_once "footer.php";
      ?>
      <!--============== //Footer Ends ==============-->
	  
      
   </body>
</html>