<?php
    include_once "connect.php";
    $query = "SELECT * FROM volunteers";
    $result = mysqli_query($connect, $query);
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- Page title -->
      <title>Time Share</title>
      <!--[if lt IE 9]>
      <script src="js/respond.js"></script>
      <![endif]-->
      <!-- Bootstrap Core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
      <!-- Icon fonts -->
      <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="fonts/flaticons/flaticon.css" rel="stylesheet" type="text/css">
      <link href="fonts/glyphicons/bootstrap-glyphicons.css" rel="stylesheet" type="text/css">
      <!-- Google fonts -->
      <link href="https://fonts.googleapis.com/css?family=Karla:400,600,700%7CCherry+Swash:400,700" rel="stylesheet">
      <!-- Style CSS -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Color Style CSS -->
      <link href="styles/maincolors.css" rel="stylesheet">
      <!-- CSS Plugins -->
      <link rel="stylesheet" href="css/plugins.css">
      <!-- LayerSlider CSS -->
      <link rel="stylesheet" href="js/layerslider/css/layerslider.css">
      <!-- Favicons-->
      <link rel="apple-touch-icon" sizes="72x72" href="apple-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="114x114" href="apple-icon-114x114.png">
      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
   </head>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
   
     
   <?php
      include_once "navbar.php";
   ?>
       <section id="team">
         <div class="container">
            <!-- Section Heading -->
            <div class="section-heading" style="margin-top: 150px">
               <h2>Our Team</h2>
            </div>
           
            <!-- Parallax object -->
            <?php 
                while($row = mysqli_fetch_assoc($result)) {
            ?>
           
           
            <!-- <div id="owl-team" class="margin1 owl-carousel"> -->
               
               <div class="col-md-8 center" style="margin-left: 15%; margin-top: 30px">
               
                  <!-- team member 1 -->
                  <div class="our-team cake-ornament">
                     <!-- picture -->
                     <div class="pic">
                        <img src="img/volunteers/<?=$row['photo']?>" alt="">
                     </div>
                     <!-- member info -->
                     <div class="team-content">
                        <h3 class="title"><?=$row['name']?></h3>
                        <span class="post"><?=$row['surname']?></span>
                        <span class="post">Birth date: <?=$row['bdate']?></span>
                        <span class="post"><?=$row['about']?></span><br>
                        <span class="post"><i class="fa fa-phone"></i>        <?=$row['number']?></span>
                        <span class="post"><i class="fa fa-envelope"></i>        <?=$row['email']?></span>
                     </div>
                     <!-- Social icons -->
                     <!-- <ul class="social">
                        <li><a href="#" class="fa fa-phone"></a></li>
                        <li><a href="#" class="fa fa-envelope"></a></li>
                        <li><a href="#" class="fa fa-google-plus"></a></li>
                        <li><a href="#" class="fa fa-linkedin"></a></li>
                     </ul> -->
                     <!--/ul  -->
                  </div>
                  <!-- /our-team -->
               </div>
              
               <?php
                    }
                ?>
               <!-- /col-md-12 -->
               <!-- /col-md-12 -->
            <!-- </div> -->
            <!-- /owl-team -->
         </div>
         <!-- /container -->
      </section>
      <!-- /section -->

      <!--============== Footer Starts ==============-->
    <footer class="bg-primary" id="about" style="background-color:#41aec0;">
         <div class="container">
            <div class="row text-center">
               <!-- social media and logo -->
               <div class="col-lg-4">
                  <h6  class="text-light">Opening Times</h6>
                  <ul class="ul-custom ul-no-margin text-light">
                     <li>Mon - fri: 9am-6pm</li>
                     <li>Holidays: Closed</li>
                  </ul>
               </div>
               <!-- /row -->
               <div class="col-lg-4">
                  <a href="#page-top"><img src="tayyor.png"  alt="" class="img-responsive center-block" style="height:150px"></a>
               </div>
               <div class="col-lg-4">
                  <!-- social-icons -->	
                  <h6  class="text-light">Follow us</h6>
                  <div class="social-media">
                     <a href="#" title=""><i class="fa fa-twitter"></i></a>
                     <a href="#" title=""><i class="fa fa-facebook"></i></a>
                     <a href="#" title=""><i class="fa fa-instagram"></i></a>
                  </div>
               </div>
               <!-- /col-lg-4 -->  			
            </div>
            <!-- /row -->
            <div class="row">
               <div class="col-md-12 credits text-center">
                  <p>Copyright © 2019 - Designed by  <a href="http://www.CyberKids.com">Cyber Kids</a></p>
                  <!-- /container -->
                  <!-- Go To Top Link -->
                  <div class="page-scroll hidden-sm hidden-xs">
                     <a href="#page-top" class="back-to-top"><i class="fa fa-angle-up"></i></a>
                  </div>
               </div>
               <!-- /col-md-12 -->
            </div>
            <!-- /row-->
         </div>
         <!-- /container -->
      </footer>
      <!-- Core JavaScript Files -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>