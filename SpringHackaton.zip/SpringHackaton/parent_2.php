<?php
echo "Hello, dear ";

if(isset($_GET["text"]))
{
echo $_GET["text"];
echo " ";
echo $_GET["DATE"];
echo "<br>";
echo "Date of birth "; 
echo $_GET["a"];
}
else
{echo "_________";}

echo "!";
echo "<br>";

if(isset($_GET["sended"]))
{
header("location: parentkabinet.php");
}


?>


<?php

	if(isset($_FILES['uploadfoto']['name'])){
		copy($_FILES['uploadfoto']['tmp_name'],"server/".basename($_FILES['uploadfoto']['name']));
	}

	if(isset($_GET['yes'])){
	header("Location: volontyorkabinet.php");
	}
?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- Page title -->
      <title>Sweetness - HTML5 Template</title>
      <!--[if lt IE 9]>
      <script src="js/respond.js"></script>
      <![endif]-->
      <!-- Bootstrap Core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
      <!-- Icon fonts -->
      <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="fonts/flaticons/flaticon.css" rel="stylesheet" type="text/css">
      <link href="fonts/glyphicons/bootstrap-glyphicons.css" rel="stylesheet" type="text/css">
      <!-- Google fonts -->
      <link href="https://fonts.googleapis.com/css?family=Karla:400,600,700%7CCherry+Swash:400,700" rel="stylesheet">
      <!-- Style CSS -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Color Style CSS -->
      <link href="styles/maincolors.css" rel="stylesheet">
      <!-- CSS Plugins -->
      <link rel="stylesheet" href="css/plugins.css">
      <!-- LayerSlider CSS -->
      <link rel="stylesheet" href="js/layerslider/css/layerslider.css">
      <!-- Favicons-->
      <link rel="apple-touch-icon" sizes="72x72" href="apple-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="114x114" href="apple-icon-114x114.png">
      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
   </head>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
   
      <!--============== Navbar Starts ==============-->
      <nav class="navbar navbar-custom navbar-fixed-top">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-brand-centered">
            <i class="fa fa-bars"></i>
            </button>
            <div class="navbar-brand-centered page-scroll">
               <a href="#page-top"><img src="img/logo.png" class="img-responsive"  alt=""></a>
            </div>
         </div>
         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="navbar-brand-centered">
            <div class="container">
               <ul class="nav navbar-nav page-scroll navbar-left">
                  <li><a href="main.php">Home</a></li>
                  <li><a href="#services">Services</a></li>
                  <li><a href="#about">About</a></li>
                  <li><a href="#reviews">Reviews</a></li>
                  <li><a href="#menu">Menu</a></li>
               </ul>
               <ul class="nav navbar-nav page-scroll navbar-right">
                  <li><a href="#catering">Catering</a></li>
                  <li><a href="#gallery">Gallery</a></li>
                  <li><a href="#team">Team</a></li>
                  <li><a href="#contact">Contact</a></li>
                  <!-- Dropdown -->
                  <li class="dropdown active">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages<b class="caret"></b></a>
                     <ul class="dropdown-menu">
                        <li><a href="blog-home.html">Blog Home</a></li>
                        <li><a href="blog-single.html">Blog Single</a></li>
                        <li class="divider"></li>
                        <li><a href="elements.html">Elements</a></li>
                     </ul>
                  </li>
               </ul>
            </div>
         </div>
         <!-- /.navbar-collapse -->
      </nav>
       <!--============== // Navbar Ends ==============-->
	   
      <!-- Preloader -->
      <div id="loading">
         <div id="loading-center">
            <div id="loading-center-absolute">
               <div class="object-load" id="object_one"></div>
               <div class="object-load" id="object_two"></div>
               <div class="object-load" id="object_three"></div>
            </div>
         </div>
      </div>
      <!-- /preloader -->

      </div>
      <!-- /container-fluid -->
      <!-- curve up svg -->
      <svg id="curveUp" class="hidden-xs hidden-sm" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 C 20 0 50 0 100 100 Z" />
      </svg>
      <!-- /curve up svg -->
      <section id="contact" class="container-fluid cake-ornament">
         <div class="container">
            <div class="col-lg-12">
               <!-- Section heading -->
               
                  
               
            </div>
            <!-- Contact icons -->
            
            <div class="row margin1">
               <div class="col-md-5">

                  <div class="form-style" id="contact_form">
                     <!-- Contact Form -->
                     <!-- Form Starts -->
                     <div class="form-group">
					 
					 <h2>Registration</h2>
					 
					
                        <label>Name<span class="required">*</span></label>
                        <input type="text" name="name" class="form-control input-field" placeholder="" required="">                    
                        <label>Surname<span class="required">*</span></label>
                        <input type="text" name="surname" class="form-control input-field" placeholder="" required="">                                        
                        <label>Date of birth<span class="required">*</span></label>
                        <input type="date" name="date of birth" class="form-control input-field" placeholder="" required="">                                        
                        <label>Adress<span class="required">*</span></label>
                        <input type="text" name="adress" class="form-control input-field" placeholder="" required="">            
						<label>Passport No.<span class="required">*</span></label>
                        <input type="text" name="passport no." class="form-control input-field" placeholder="" required="">            
						<label>Phone number<span class="required">*</span></label>
                        <input type="text" name="phone number" class="form-control input-field" placeholder="" required="">            
                        
						
						<section id="team">
	 	  
	  
      <!-- ==== Contact ==== -->
      <section id="contact" class="container-fluid cake-ornament">
         <div class="container">
            <div class="col-lg-12">
               <!-- Section heading -->
               
                  
               
            </div>
            <!-- Contact icons -->
            
            <div class="row margin1">
               <div class="col-md-5">

                  <div class="form-style" id="contact_form">
                     <!-- Contact Form -->
                     <!-- Form Starts -->
                     <div class="form-group">
					 
					 <h2>Enter information about your child</h2>
					 
					
                        <label>Name<span class="required">*</span></label>
                        <input type="text" name="name" class="form-control input-field" placeholder="" required="">                    
                        <label>Surname<span class="required">*</span></label>
                        <input type="text" name="surname" class="form-control input-field" placeholder="" required="">                                        
                                       
						
						
						<label>Write about your child<span class="required">*</span></label>
                        <textarea name="bio" type="text" class="textarea-field form-control" rows="4" placeholder="" required=""></textarea>
							<label>Child's photo</label>						
                        <input type="file" name="uploadfoto" class="form-control input-field" placeholder="">             
						
						
						
						
      <!--============== Footer Starts ==============-->
      <svg id="curveUpColor" class="hidden-xs" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 C 20 0 50 0 100 100 Z" />
      </svg>
       <!--============== //Footer Ends ==============-->
	  
      <!-- Core JavaScript Files -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>

