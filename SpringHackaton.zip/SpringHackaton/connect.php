<?php
    define("HOST","localhost");
    define("BAZA","dbspring1");
    define("PASSWORD","");
    define("USER","root");

    $connect =mysqli_connect(HOST,USER,PASSWORD,BAZA);
   

?>