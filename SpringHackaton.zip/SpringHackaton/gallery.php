?php include("control.php"); ?>

<!DOCTYPE html>
<html lang="en">
   <?php
     
   ?>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<?php
      include_once "navbar.php";
   ?>
	  <section id="gallery" class="light-bg2 cake-ornament container-fluid">
         <!-- Section heading -->
         <div class="section-heading" style="margin-bottom: 0px; margin-top: 150px;">
            <h2>Our Gallery</h2>
         </div>
         <div class="container">
            <!-- Polaroids -->
            <ul class="polaroids col-md-12">
               <!-- image1 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_134116.jpg" class="img-responsive"/>
                     <p>Eco Park</p>
               
               </li>
               <!-- image2 -->
			   <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_143823.jpg" class="img-responsive"/>
                     <p>Smile</p>
               
               </li>
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_134424.jpg" class="img-responsive"/>
					 <p>Rest time</p>
               </li>
               <!-- image3 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_133825.jpg" class="img-responsive"/>
                     <p>Selfie</p>
               </li>
               <!-- image4 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_150346.jpg" class="img-responsive"/>
                     <p>We love Tashkent</p>
               </li>
               <!-- image5 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_105009.jpg" class="img-responsive"/>
                     <p>Chess</p>
               </li>
               <!-- image6 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_105041.jpg" class="img-responsive"/>
                     <p>Badminton</p>
               </li>
               <!-- image7 -->
               <li class="polaroid-item  col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_112914.jpg" class="img-responsive"/>
                     <p>Jumping</p>
               </li>
               <!-- image8 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_110227.jpg" class="img-responsive"/>
                     <p>Picnic</p>
               </li>
               <!-- image9 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_150647.jpg" class="img-responsive"/>
                     <p>Say: "Cheese"</p>
               </li>
               <!-- image10 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_150834.jpg" class="img-responsive"/>
                     <p>Cycling</p>
               </li>
               <!-- image11 -->
               <li class="polaroid-item col-lg-3 col-md-6 col-sm-6">
                     <img alt="" src="img/img/SONY DSC-HX200V_20190308_133628.jpg" class="img-responsive"/>
                     <p>Skating</p>
               </li>
              
            </ul>
            <!-- /ul-polaroids --> 
         </div>
         <!-- /container -->
      </section>
      <!-- /section -->
     
     
      <!-- ==== Contact ==== -->
      <section id="contact" class="container-fluid">
         <div class="container">
            <div class="col-lg-12">
               <!-- Section heading -->
               <div class="section-heading">
                  <h2>Contact Us</h2>
               </div>
            </div>
            <!-- Contact icons -->
            <div class="row">
               <div class="col-lg-12 col-md-12">
                  <div class="col-md-6">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-envelope top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Send us a Message</p>
                           <p>Email address: <br/><a href="mailto:email@timeshare.com">email@timeshare.com</a></p>
                        </div>
                     </div>
                  </div>
                  <!-- /cont
                  <!-- /contact-icon-->
                  <div class="col-md-6">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-phone top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Call us</p>
                           <p>Phone numbers: <br/>(94) 123-45-67 <br/>(94) 123-45-67</p>
                        </div>
                     </div>
                     <!-- /contact-icon-->
                  </div>
                  <!-- /col-md-4-->
               </div>
               <!-- /col-lg -->
            </div>
           
            <!--/row -->   
         </div>
         <!-- /container-->
      </section>
      <!-- / section-->
      <!--============== Footer Starts ==============-->
    <footer class="bg-primary" id="about" style="background-color:#41aec0;">
         <div class="container">
            <div class="row text-center">
               <!-- social media and logo -->
               <div class="col-lg-4">
                  <h6  class="text-light">Opening Times</h6>
                  <ul class="ul-custom ul-no-margin text-light">
                     <li>Mon - fri: 9am-6pm</li>
                     <li>Holidays: Closed</li>
                  </ul>
               </div>
               <!-- /row -->
               <div class="col-lg-4">
                  <a href="#page-top"><img src="tayyor.png"  alt="" class="img-responsive center-block" style="height:150px"></a>
               </div>
               <div class="col-lg-4">
                  <!-- social-icons -->	
                  <h6  class="text-light">Follow us</h6>
                  <div class="social-media">
                     <a href="#" title=""><i class="fa fa-twitter"></i></a>
                     <a href="#" title=""><i class="fa fa-facebook"></i></a>
                     <a href="#" title=""><i class="fa fa-instagram"></i></a>
                  </div>
               </div>
               <!-- /col-lg-4 -->  			
            </div>
            <!-- /row -->
            <div class="row">
               <div class="col-md-12 credits text-center">
                  <p>Copyright © 2019 - Designed by  <a href="http://www.CyberKids.com">Cyber Kids</a></p>
                  <!-- /container -->
                  <!-- Go To Top Link -->
                  <div class="page-scroll hidden-sm hidden-xs">
                     <a href="#page-top" class="back-to-top"><i class="fa fa-angle-up"></i></a>
                  </div>
               </div>
               <!-- /col-md-12 -->
            </div>
            <!-- /row-->
         </div>
         <!-- /container -->
      </footer>
      <!-- Core JavaScript Files -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>