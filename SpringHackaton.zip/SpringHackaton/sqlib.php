<?php 
function create_db($database_name='sqlite')
{
	if(gettype($database_name)=='integer')
	{$database_name = (string)$database_name;}
	if(gettype($database_name)=='string')
	{$db = new PDO('sqlite: '.$database_name.'.php');
	return $db;}
	if(gettype($database_name)=='array')
	{$cdb = count($database_name);
	for($i=0; $i<$cdb; $i++)
	{$db_array[$i] = new PDO('sqlite: '.$database_name[$i].'.php');}
	return $db_array;}
}



function create_tb($db, $table_name, $array_of_fields, $PRIMARY_KEY=NULL)
{
	$id = 'id INTEGER';
	$pk = ' PRIMARY KEY';
	$string_query = '';
	$c=NULL;
	
	if(gettype($array_of_fields)=='integer')
	{$array_of_fields = (string)$array_of_fields;}
	if(gettype($array_of_fields)=='string')
	{
		if($PRIMARY_KEY === $array_of_fields)
		{$result = $db->query('CREATE TABLE '.$table_name.' (id INTEGER , '.$array_of_fields.' PRIMARY KEY)');}
		else
		{$result = $db->query('CREATE TABLE '.$table_name.' (id INTEGER PRIMARY KEY , '.$array_of_fields.')');}
		return $result;
	}
	if(gettype($array_of_fields)=='array')
	{
	$aof = count($array_of_fields);
	
	for($j=0; $j<$aof; $j++)
	{
		if($array_of_fields[$j]==$PRIMARY_KEY)
		{$array_of_fields[$j] = $array_of_fields[$j].$pk; $c=1; break;}
		else{$c=NULL;}
	}
	
	if($c)
	{	
		$string_query = $id;
		for($j=0; $j<$aof; $j++)
		{$string_query = $string_query.', '.$array_of_fields[$j];}
	}
	else
	{
		$string_query = $id.$pk;
		for($j=0; $j<$aof; $j++)
		{$string_query = $string_query.', '.$array_of_fields[$j];}
	}

	$result = $db->query('CREATE TABLE '.$table_name.' ('.$string_query.')');
	return $result;
	}
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function columns($db, $table_name)
{
	$result = $db->prepare('pragma table_info('.$table_name.')');
	$result->execute(); 
	$i=0;
	$result_arr = array();
	while($row = $result->fetchObject()) {$row = (array)$row; $result_arr[$i] = $row['name']; $i++;}
	return $result_arr;
}


function insert($db, $table_name, $fields_array=array())
{
	$columns = columns($db, $table_name);
	$table_fields = count($columns);
	$array_fields = count($fields_array)+1;
	if($table_fields===$array_fields)
	{
		$string_fields = $columns[1];
		$string_values = "'".$fields_array[0]."'";
		$e = count($columns);
		for($i=1; $i<($e-1); $i++)
		{
			$string_fields .= ', '.$columns[$i+1];
			if(!isset($fields_array[$i])){$fields_array[$i]='0';}
			$string_values .= ', '."'".$fields_array[$i]."'";
		}

		$result = $db->prepare('INSERT INTO '.$table_name.' ( '.$string_fields.' ) VALUES ( '.$string_values.' )'); 
		$result->execute();
		return $result;
	}
	elseif($table_fields>$array_fields)
	{
		$string_fields = $columns[1];
		$string_values = $fields_array[0];
		for($i=1; $i<(count($columns)-1); $i++)
		{
			$string_fields .= ', '.$columns[$i+1];
			if(!isset($fields_array[$i])){$fields_array[$i]='0';}
			$string_values .= ', '.$fields_array[$i];
		}

		$result = $db->prepare('INSERT INTO '.$table_name.' ( '.$string_fields.' ) VALUES ( '.$string_values.' )'); 
		$result->execute();
		return $result;
	}
	elseif($table_fields<$array_fields)
	{
		$string_fields = $columns[1];
		$string_values = $fields_array[0];
		for($i=1; $i<count($fields_array); $i++)
		{
			$string_fields .= ', '.$columns[$i+1];
			$string_values .= ', '.$fields_array[$i];
		}

		$result = $db->prepare('INSERT INTO '.$table_name.' ( '.$string_fields.' ) VALUES ( '.$string_values.' )'); 
		$result->execute();
		return $result;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function insert_c($db, $table_name, $fields_array=array())
{	
		$keys_array = array_keys($fields_array);
		$values_array = array_values($fields_array);
		$keys_string = '';
		$values_string = '';
		$c_fields_array = count($fields_array);
		for($i=0; $i<$c_fields_array; $i++)
		{
			$keys_string.="'".$keys_array[$i]."'";
			if($i<($c_fields_array-1)){$keys_string.=', ';}
			
			$values_string.="'".$values_array[$i]."'";
			if($i<($c_fields_array-1)){$values_string.=', ';}
		}
		$keys_string;
		$values_string;
		$result = $db->prepare('INSERT INTO '.$table_name.' ( '.$keys_string.' ) VALUES ( '.$values_string.' )'); 
		$result->execute();
		return $result;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



function delete($db, $table_name, $par3/*field_name*/, $par4=NULL/*value*/)
{
	if($par4!=NULL)
	{
		$result = $db->prepare('DELETE FROM '.$table_name.' WHERE '.$par3.'='."'".$par4."'".''); 
		$result->execute();
		return $result;
	}
	else
	{
		$par3 = (int) $par3;
		$result = $db->prepare('DELETE FROM '.$table_name.' WHERE id='."'".$par3."'".''); 
		$result->execute();
		return $result;
	}
}


function update($db, $table_name, $par3, $par4, $par5, $par6)
{
	$result = $db->prepare('UPDATE '.$table_name.' SET '.$par3.'='."'".$par4."'".' WHERE '.$par5.'='."'".$par6."'".';'); 
	$res = $result->execute(); 
	return isset($res);
}

function lite_query($db, $string_query)
{
	$result = $db->prepare($string_query); 
	$result->execute(); 
	return $result;
}

function dbo_as_dual($db_object)
{
	$i=0;
	$result_arr = array();
		while($row = $db_object->fetchObject()) { $row = (array) $row; $result_arr[$i] = $row; $i++;}
	return $result_arr;
}



function update_c($db, $table_name, $fields_array=array(/* 'field1' => 'value1', 'field2' => 'value2', ... */), $key, $value)
{	
	$keys_array = array_keys($fields_array);
	$values_array = array_values($fields_array);
		$fields_values = '';
		$c_fields_array = count($fields_array);
		for($i=0; $i<$c_fields_array; $i++)
		{
			$fields_values.="'".$keys_array[$i]."'".'='."'".$values_array[$i]."'";
						if($i<($c_fields_array-1)){$fields_values.=', ';}
		}

		$result = $db->prepare('UPDATE '.$table_name.' SET '.$fields_values.'  WHERE '.$key.'='."'".$value."'".';'); 
		$result->execute();
		return $result;
}

/*
function dbo_as_mono($db_object)
{
			$i=0;
		$result_arr = array();
		while($row = $db_object->fetchObject()) { $row = (array) $row; $result_arr[$i] = $row; $i++;}
	return $result_arr;
}
*/


function drop_tb($db, $table_name)
{
	lite_query($db, "DROP TABLE '".$table_name."';");
}
	
	
function select($db, $table_name, $par3=NULL, $par4=NULL)
{
	$columns = columns($db, $table_name);
	if(!isset($par3) and !isset($par4))
	{
		$result = $db->prepare('SELECT * FROM '.$table_name.';');
		$result->execute();
		
		$i=0;
		$result_arr = array();
		while($row = $result->fetchObject()) { $row = (array) $row; 
		for($j=0; $j<count($columns); $j++) {$result_arr[$i][$columns[$j]] = $row[$columns[$j]]; }  $i++;}
			
	return $result_arr;
	}
	elseif(isset($par3) and !isset($par4))
	{
		$par3 = (string)$par3;
		$result = $db->prepare('SELECT * FROM '.$table_name.' WHERE id='.$par3.';'); 
		$result->execute();
		$i=0;
		$result_arr = array();
		while($row = $result->fetchObject()) { $row = (array) $row; 
		for($j=0; $j<count($columns); $j++) {$result_arr[$columns[$j]] = $row[$columns[$j]]; } }

		return $result_arr;
	
	}
	else
	{
		$result = $db->prepare('SELECT * FROM '.$table_name.' WHERE '.$par3.'='."'".$par4."'".';'); 
		$result->execute();
		$i=0;
		$result_arr = array();
		while($row = $result->fetchObject()) { $row = (array) $row;
		for($j=0; $j<count($columns); $j++) {$result_arr[$i][$columns[$j]] = $row[$columns[$j]]; }  $i++;}

		return $result_arr;
	}
}





function view_tb($db, $table_name)
{

	echo '<br/><h3>TABLE '.$table_name.'</h3><table border="1">';

	$columns = columns($db, $table_name);
	
	for($j=0; $j<count($columns); $j++)
		{
			echo '<th>'.$columns[$j].'</th>';
		}

	$res = select($db, $table_name);
		
	for($i=0; $i<count($res); $i++)
	{
		echo '<tr>';	
		for($j=0; $j<count($columns); $j++)
		{
			echo '<td>'.$res[$i][$columns[$j]].'</td>';
		}
		echo '</tr>';
	}
		echo '</table><br/>';
}

	function select_c($db, $table_name, $par3/* id */, $limit=NULL)
	{
	if(empty($limit))
	{
		$par3 = (string)$par3;
		$result = $db->prepare('SELECT '.$par3.' FROM '.$table_name.';'); 
		$result->execute();
		$i=0;
		$result_arr = array();
		while($row = $result->fetchObject()) { $row = (array) $row; $result_arr[$i] = $row; $i++;}
		return $result_arr;
	}
	elseif($limit)
	{
		$par3 = (string)$par3;
		$result = $db->prepare('SELECT '.$par3.' FROM '.$table_name.' LIMIT '.$limit.';'); 
		$result->execute();
		$i=0;
		$result_arr = array();
		while($row = $result->fetchObject()) { $row = (array) $row; $result_arr[$i] = $row; $i++;}
		return $result_arr;
	}
	
	}
	
	function select_r($db, $table_name, $fields, $where_field=NULL, $value=NULL, $limit=NULL)
	{
	
		if(gettype($fields)=='array')
		{
			$fields_string= '';
			$c_fields = count($fields);
			for($i=0; $i<$c_fields; $i++)
			{
					$fields_string.="".$fields[$i]."";
					if($i<($c_fields-1)){$fields_string.=', ';}
			}
		}
		elseif(gettype($fields)=='string')
		{$fields_string = $fields;}
	
		$db_object = NULL;
	
		if($limit===NULL)
		{
			if($where_field===NULL and $value===NULL)
			{$db_object = lite_query($db, "SELECT ".$fields_string." FROM ".$table_name.";");}
			else
			{$db_object = lite_query($db, "SELECT ".$fields_string." FROM ".$table_name." WHERE ".$where_field."="."'".$value."'".";");}		
		}
		else
		{
			if($where_field===NULL and $value===NULL)
			{$db_object = lite_query($db, "SELECT ".$fields_string." FROM ".$table_name." LIMIT ".$limit.";");}
			else
			{$db_object = lite_query($db, "SELECT ".$fields_string." FROM ".$table_name." WHERE ".$where_field."="."'".$value."'"." LIMIT ".$limit.";");}		
		}
		
		$result = dbo_as_dual($db_object);
		return $result;
	}
	
	function info_tb($db, $table_name)
	{
		$res = lite_query($db, 'pragma table_info('.$table_name.')');
		$result = dbo_as_dual($res);
		return $result;
	}
		
	function count_tb($db, $table_name, $field_name = NULL)
	{
		$res = lite_query($db, 'SELECT count(*) FROM '.$table_name.';');
		$result = dbo_as_dual($res);
		$result = $result[0]['count(*)'];
		return $result;
	}
	
	function max_tb($db, $table_name, $field_name = 'id')
	{
		$res = lite_query($db, 'SELECT max('.$field_name.') FROM '.$table_name.';');
		$result = dbo_as_dual($res);
		$result = $result[0]['max('.$field_name.')'];
		return $result;
	}
	
	function backup_tb($db, $table_name, $backup_name)
	{
		$columns = columns($db, $table_name);
		$columns = array_diff($columns, array('id'));
		$columns = implode(', ', $columns);
		$res = select_c($db, $table_name, $columns);
		$res = serialize($res);
		file_put_contents($backup_name, $res);
	}


	function unbackup_tb($db, $table_name, $backup_name)
	{
		$backup = file_get_contents($backup_name);
		$backup = unserialize($backup);
		$c_backup = count($backup);
		for($i=0; $i<$c_backup; $i++)
		{
			$l =insert_c($db, $table_name, $backup[$i]);
		}
		return $l;
	}

	function add_column($db, $table_name, $added_column_name)
	{
		$res = lite_query($db, "ALTER TABLE '".$table_name."' ADD COLUMN '".$added_column_name."'");
		return $res;
	}
	
	
	
	function filtr($value)
{
$value = htmlspecialchars(stripslashes(strip_tags($value)), ENT_QUOTES);

return $value = str_replace("'", "`", $value); 
}
